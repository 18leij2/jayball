How to play the game, JayBall:
- The menu screen displays text "Press Enter To Start", press the binded [START] key to begin the game.
- When not drawing a line, press [SELECT] to pause the game.
- When paused, press [START] to resume the game.
- Use binded [UP], [DOWN], [LEFT], [RIGHT], to draw lines.
- Avoid the ball and trap it in a container smaller than 625 pixels!
- Upon winning or losing, press the binded [A] key to restart to main menu.

Flair:
- Pause function (with pause icon that lights up on the bottom left when activated)
- Heart indicators on top left to represent lives
- Menu screen that waits for user input before starting the game
- Special win and lose screens that display the end status
- Option to quick retry for easy testing and replayability